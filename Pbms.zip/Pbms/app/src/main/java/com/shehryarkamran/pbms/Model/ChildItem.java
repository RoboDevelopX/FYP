package com.shehryarkamran.pbms.Model;

/**
 * class : represents a childItem
 */
public class ChildItem {

    //category name
    private final String category;

    //price
    private final double price;

    //date
    private final String date;

    //notes
    private final String notes;

    //month
    private String month;

    //uniqueId
    private int uniqueID;

    //constructor
    public ChildItem(String category,double price,String date,String notes){
        this.category=category;
        this.date=date;
        this.price=price;
        this.notes=notes;

    }

    /**
     * below are the setters and getters for each attributes
     */
    public void setUniqueID(int id){
        this.uniqueID=id;
    }

    public void setMonth(String month){
        this.month=month;
    }


    public int getUniqueID(){
        return uniqueID;
    }

    public String getCategory(){
        return category;
    }

    public String getDate(){
        return date;
    }

    public String getNotes(){
        return notes;
    }

    public String getMonth(){
        return month;
    }

    public double getPrice(){
        return price;
    }
}