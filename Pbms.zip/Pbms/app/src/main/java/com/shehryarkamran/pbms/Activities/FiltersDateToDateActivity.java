package com.shehryarkamran.pbms.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog;
import com.shehryarkamran.pbms.R;
import com.shehryarkamran.pbms.Utils.Themer;

import java.util.Calendar;

/**
 * FiltersDateToDateDialog class that extends DialogFragment is used when we want to find expenses or incomes with date between two
 * dates. HistoryActivity calls this class more specific in filters.
 */
public class FiltersDateToDateActivity extends AppCompatActivity {

    //View objects for the XML management
    private Button bOk, bCancel;
    private ImageButton ibFrom, ibTo;
    private EditText etFrom, etTo;
    //variable flag is used because we want to know which button the user pressed so we initialise the right date
    //and variable expense is to check if this fragment is called for expenses or incomes
    private boolean flag;

    private CalendarDatePickerDialog Cdialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //setting theme
        Themer.setThemeToActivity(this);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_filters_datetodate);

        //init views
        initUI();

        //set up listeners , adapter etc
        setUpUI();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
    }


    private void initUI() {

        etFrom = findViewById(R.id.etDateFrom);
        ibFrom = findViewById(R.id.ibFrom);

        etTo = findViewById(R.id.etDateTo);
        ibTo = findViewById(R.id.ibTo);

        Calendar c = Calendar.getInstance();
        String day = c.get(Calendar.DAY_OF_MONTH) + "";
        String month = (c.get(Calendar.MONTH) + 1) + "";
        if (c.get(Calendar.DAY_OF_MONTH) < 10) {
            day = "0" + c.get(Calendar.DAY_OF_MONTH);
        }
        if (c.get(Calendar.MONTH) + 1 < 10) {
            month = "0" + (c.get(Calendar.MONTH) + 1);
        }

        String date = day + "-" + month + "-" + c.get(Calendar.YEAR);
        etFrom.setText(date);
        etTo.setText(date);

        bOk = findViewById(R.id.bOK);
        bCancel = findViewById(R.id.bCancel);

    }

    private void setUpUI() {

        //from button listener
        ibFrom.setOnClickListener(view -> {
            flag = true;
            Calendar c = Calendar.getInstance();
            Cdialog = CalendarDatePickerDialog.newInstance(dtdListener,
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
            Cdialog.show(getSupportFragmentManager(), "Calendar Dialog");

        });

        //to button listener
        ibTo.setOnClickListener(view -> {
            flag = false;
            Calendar c = Calendar.getInstance();
            Cdialog = CalendarDatePickerDialog.newInstance(dtdListener,
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
            Cdialog.show(getSupportFragmentManager(), "Calendar Dialog");

        });

        bOk.setOnClickListener(view -> {

            Intent resultIntent = getIntent();
            resultIntent.putExtra("From", etFrom.getText().toString());
            resultIntent.putExtra("To", etTo.getText().toString());
            setResult(Activity.RESULT_OK, resultIntent);
            finish();


        });
        //cancel button listener
        bCancel.setOnClickListener(view -> finish());

    }

    private final CalendarDatePickerDialog.OnDateSetListener dtdListener = new CalendarDatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(CalendarDatePickerDialog calendarDatePickerDialog, int cYear, int cMonth, int cDay) {

            String month, day, date;
            cMonth++;
            if (cMonth < 10) {
                month = "0" + cMonth;
            } else {
                month = String.valueOf(cMonth);
            }
            if (cDay < 10) {
                day = "0" + cDay;
            } else {
                day = String.valueOf(cDay);
            }
            date = day + "-" + month + "-" + cYear;

            if (flag) {
                etFrom.setText(date);

            } else {
                etTo.setText(date);
            }
        }
    };
}