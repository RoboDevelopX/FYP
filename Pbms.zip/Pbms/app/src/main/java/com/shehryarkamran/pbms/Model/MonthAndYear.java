package com.shehryarkamran.pbms.Model;

/**
 * class : represents a Month and Year
 */
public class MonthAndYear {

    private final String month;
    private final int year;

    //constructor
    public MonthAndYear(String month,int year){
        this.month=month;
        this.year=year;
    }

    public String getMonth(){
        return month;
    }

    public int getYear(){
        return year;
    }

    @Override
    public boolean equals(Object o) {
        if(o==null) return false;
        if(!(o instanceof  MonthAndYear)) return false;

        MonthAndYear other=(MonthAndYear) o;
        return this.month.equals(other.month) && this.year==other.year;
    }

    @Override
    public int hashCode() {
        return year *this.month.hashCode();
    }
}