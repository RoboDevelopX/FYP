package com.shehryarkamran.pbms.Model;

import java.io.Serializable;

/**
 * class : represents a expenseItem
 */
public class ExpenseItem implements Serializable {

    //expense id
    private int id;

    //expense category
    private String category;

    //expense notes
    private final String notes;

    //expense date
    private String date;

    //expense price
    private final double price;

    //constructor
    public ExpenseItem(String category, String notes, double price, String date) {
        this.category = category;
        this.notes = notes;
        this.price = price;
        this.date = date;
    }

    /**
     * below are the setters and getters for each attributes
     */
    public void setCategory(String category) {
        this.category = category;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public String getNotes() {
        return notes;
    }

    public double getPrice() {
        return price;
    }

    public String getDate() {
        return date;
    }

    public int getId() {
        return id;
    }
}