package com.shehryarkamran.pbms.Extra;

class MagnificentChartItem {

//Constants

    public final int color;
    public final double value;
    private final String title;

// Constructors

    public MagnificentChartItem(String title, double value, int color){
        this.color = color;
        this.value = value;
        this.title = title;
    }
}