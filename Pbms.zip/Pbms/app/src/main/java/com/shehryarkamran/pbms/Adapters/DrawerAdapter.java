package com.shehryarkamran.pbms.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.shehryarkamran.pbms.R;

/**
 * Making calls to findViewById() is really slow in practice, and if your adapter has to call it for each View in
 * your row for every single row then you will quickly run into performance issues.What the ViewHolder class does is
 * cache the call to findViewById(). Once your ListView has reached the max amount of rows it can display on a screen,
 * Android is smart enough to begin recycling those row Views. We check if a View is recycled with if (convertView == null).
 * f it is not null then we have a recycled View and can just change its values, otherwise we need to create a new row View.
 * The magic behind this is the setTag() method which lets us attach an arbitrary object onto a View object, which is how we save
 * the already inflated View for future reuse.
 */

public class DrawerAdapter extends ArrayAdapter<String> {

    public DrawerAdapter(Context context, int resource, String[] activities) {
        super(context, resource, activities);
    }

    private class ViewHolder {

        private TextView tvActivity;
        private ImageView ivActivity;

    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        String activity = getItem(position);
        LayoutInflater mInflater = (LayoutInflater) getContext()
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            assert mInflater != null;
            convertView = mInflater.inflate(R.layout.drawer_item, null);
            holder = new ViewHolder();
            holder.tvActivity = convertView.findViewById(R.id.TvDrawer);
            holder.ivActivity = convertView.findViewById(R.id.IvDrawer);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tvActivity.setText(activity);
        switch (position) {

            case 0:
                holder.ivActivity.setImageResource(R.drawable.ic_history);
                break;
            case 1:
                holder.ivActivity.setImageResource(R.drawable.income);
                break;
            case 2:
                holder.ivActivity.setImageResource(R.drawable.expense);
                break;
            case 3:
                holder.ivActivity.setImageResource(R.drawable.ic_pie);
                break;
            case 4:
                holder.ivActivity.setImageResource(R.drawable.ic_bars);
                break;
            case 5:
                holder.ivActivity.setImageResource(R.drawable.ic_categories);
                break;
            case 6:
                holder.ivActivity.setImageResource(R.drawable.ic_settings);
                break;
            case 7:
                holder.ivActivity.setImageResource(R.drawable.ic_exit);
                break;

        }
        return convertView;
    }


    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        String activity = getItem(position);
        LayoutInflater mInflater = (LayoutInflater) getContext()
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            assert mInflater != null;
            convertView = mInflater.inflate(R.layout.drawer_item, null);
            holder = new ViewHolder();
            holder.tvActivity = convertView.findViewById(R.id.TvDrawer);
            holder.ivActivity = convertView.findViewById(R.id.IvDrawer);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tvActivity.setText(activity);
        switch (position) {

            case 0:
                holder.ivActivity.setImageResource(R.drawable.ic_history);
                break;
            case 1:
                holder.ivActivity.setImageResource(R.drawable.income);
                break;
            case 2:
                holder.ivActivity.setImageResource(R.drawable.expense);
                break;
            case 3:
                holder.ivActivity.setImageResource(R.drawable.ic_pie);
                break;
            case 4:
                holder.ivActivity.setImageResource(R.drawable.ic_bars);
                break;
            case 5:
                holder.ivActivity.setImageResource(R.drawable.ic_categories);
                break;
            case 6:
                holder.ivActivity.setImageResource(R.drawable.ic_settings);
                break;
            case 7:
                holder.ivActivity.setImageResource(R.drawable.ic_exit);
                break;


        }
        return convertView;
    }
}