package com.shehryarkamran.pbms.Activities;

import android.Manifest;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;

import com.shehryarkamran.pbms.Adapters.GridAdapter;
import com.shehryarkamran.pbms.Data.MoneyDatabase;
import com.shehryarkamran.pbms.Extra.ColorPicker.ColorPickerDialog;
import com.shehryarkamran.pbms.Extra.ColorPicker.ColorPickerSwatch;
import com.shehryarkamran.pbms.Model.GridItem;
import com.shehryarkamran.pbms.R;
import com.shehryarkamran.pbms.Utils.BackupRestoreSD;
import com.shehryarkamran.pbms.Utils.SharedPrefsManager;
import com.shehryarkamran.pbms.Utils.Themer;

import java.util.ArrayList;

//setting activity of app
public class SettingsActivity extends PreferenceActivity
        implements SharedPreferences.OnSharedPreferenceChangeListener {


    private boolean backup;
    private BackupRestoreDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //setting theme
        Themer.setThemeToActivity(this);

        super.onCreate(savedInstanceState);

        //init preference screen from xml file
        addPreferencesFromResource(R.xml.preferences);

        //init the summaries for the screens
        initSummaries(getPreferenceScreen());

        setPreferenceActions();
    }


    //set all the preferences and their actions
    private void setPreferenceActions() {

        //when user clicks on "profile" preference item
        //launch intent with target the UserDetailsActivity class
        Preference screen = findPreference(getResources().getString(R.string.pref_key_profile));
        Intent i = new Intent(this, UserDetailsActivity.class);
        screen.setIntent(i);

        //when user clicks on Backup preference item
        //call a dialog with the options that user can perform the backup
        screen = findPreference(getResources().getString(R.string.pref_key_backup));
        screen.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {

                backup = true;
                dialog = new BackupRestoreDialog().newInstance(backup);
                dialog.show(getFragmentManager(), "dialog");

                return false;
            }
        });

        //when user clicks on Restore preference item
        //call a dialog with the options that user can perform the restore
        screen = findPreference(getResources().getString(R.string.pref_key_restore));
        screen.setOnPreferenceClickListener(preference -> {

            backup = false;
            dialog = new BackupRestoreDialog().newInstance(backup);
            dialog.show(getFragmentManager(), "dialog");

            return false;
        });

        //when the user clicks on the "theme" preference item
        screen = findPreference(getResources().getString(R.string.pref_key_theme));
        screen.setDefaultValue(getResources().getColor(R.color.background_material_dark));
        screen.setOnPreferenceClickListener(preference -> {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
            int[] mColor = new int[]{
                    getResources().getColor(R.color.background_material_dark),
                    getResources().getColor(R.color.background_material_light),
                    getResources().getColor(R.color.skyblue_colorPrimary),
                    getResources().getColor(R.color.grey_colorPrimary)
            };
            ColorPickerDialog dialog = ColorPickerDialog.newInstance(R.string.color_picker_default_title, mColor, 0, 2, ColorPickerDialog.SIZE_LARGE);
            dialog.setSelectedColor(prefs.getInt(getResources().getString(R.string.pref_key_theme), getResources().getColor(R.color.background_material_light)));
            dialog.setOnColorSelectedListener(colorSetListener);
            dialog.show(getFragmentManager(), "color");
            return false;
        });
        //when user click on "deleteAllRecord" preference item
        screen = findPreference(getResources().getString(R.string.pref_key_delete_history));
        screen.setOnPreferenceClickListener(preference -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this,R.style.MyDialogThemeLight);
            builder.setTitle(getResources().getString(R.string.pref_title_delete_history));
            builder.setMessage(getResources().getString(R.string.dialog_text_delete_history_confirm));
            builder.setPositiveButton("Yes", (dialog, which) -> {

                //call delete income-expense methods from database
                MoneyDatabase db = new MoneyDatabase(SettingsActivity.this);
                db.deleteAllIncome();
                db.deleteAllExpense();
                db.close();
                dialog.cancel();
                finish();
            });
            builder.setNegativeButton("No", (dialog, which) -> dialog.cancel());
            builder.show();
            return false;
        });
    }

    private final ColorPickerSwatch.OnColorSelectedListener colorSetListener = color -> {
        //when color is selected
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
        SharedPreferences.Editor editor = prefs.edit();

        //save the new theme color
        editor.putInt(getResources().getString(R.string.pref_key_theme), color);
        editor.apply();

        //set the theme changed variable to true
        SharedPrefsManager manager = new SharedPrefsManager(SettingsActivity.this);
        manager.startEditing();
        manager.setPrefsThemeChanged(true);
        manager.commit();

        //and then destroy the dialog
        Intent i = getIntent();
        overridePendingTransition(0, 0);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
        overridePendingTransition(0, 0);
        startActivity(i);

    };

    @Override
    protected void onResume() {
        super.onResume();
        //on resume , update the summaries , and  any preferences launched
        initSummaries(getPreferenceScreen());
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        new SharedPrefsManager(SettingsActivity.this);
        Log.d("Resume", "Resume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    //updating sharedPreference
    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

        updatePrefSummary(findPreference(key));
    }

    //init summaries of the preference screen
    private void initSummaries(Preference p) {

        //if preference is a PreferenceGroup , init summary for each child in it
        if (p instanceof PreferenceGroup) {
            PreferenceGroup pGrp = (PreferenceGroup) p;
            for (int i = 0; i < pGrp.getPreferenceCount(); i++) {
                initSummaries(pGrp.getPreference(i));
            }
        } else {
            //else just update this item's summary
            updatePrefSummary(p);
        }
    }

    //update summary accordingly to preference key
    private void updatePrefSummary(Preference p) {

        if (p.getKey().equals(getResources().getString(R.string.pref_key_currency))) {
            ListPreference pref = (ListPreference) p;
            pref.setSummary(pref.getValue());
        }
    }

    /**
     * Inner class BackupRestoreDialog implements the basic dialog with backup and restore options for the user.
     * More specific the user got a option for backup and restore which are using SD card.
     */
    public static class BackupRestoreDialog extends DialogFragment {

        private GridView gridView;
        private Dialog dialog;
        private boolean backup;

        public BackupRestoreDialog() {}


        BackupRestoreDialog newInstance(boolean backup) {
            BackupRestoreDialog d = new BackupRestoreDialog();
            Bundle bundle = new Bundle();
            bundle.putBoolean("backup", backup);
            d.setArguments(bundle);

            return d;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            dialog = new Dialog(getActivity());
            dialog.setContentView(R.layout.backup_dialog);

            backup = getArguments().getBoolean("backup");

            if (backup)
                dialog.setTitle(getActivity().getResources().getString(R.string.destination));
            else dialog.setTitle(getActivity().getResources().getString(R.string.restore));

            initUI();
            init();
            initListeners();
            return dialog;
        }

        private void initUI() {
            gridView = dialog.findViewById(R.id.gridview);
        }

        private void init() {
            ArrayList<GridItem> items = new ArrayList<>();
            items.add(new GridItem(BitmapFactory.decodeResource(getResources(), R.drawable.sd), "SD card"));

            GridAdapter adapter = new GridAdapter(getActivity(), R.layout.grid_item_menu, items);
            gridView.setAdapter(adapter);
        }

        private void initListeners() {
            gridView.setOnItemClickListener((parent, view, position, id) -> {
                //check if already permission granted or not, if granted then perform backup/restore action
                //else request permission
                int result = ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if (position == 0) {
                    if (backup) {
                        if (result == PackageManager.PERMISSION_GRANTED) {
                            String MoneyDBpath = "/data/" + getActivity().getPackageName() + "/databases/MoneyDatabase";
                        String MoneyOutputName = "/TransactionsBackup";
                        BackupRestoreSD backupRestoreSD = new BackupRestoreSD(MoneyDBpath, MoneyOutputName, getActivity());
                        boolean MoneySuccess = backupRestoreSD.backup();

                        String CategoriesDBpath = "/data/" + getActivity().getPackageName() + "/databases/categories";
                        String CategoriesOutputName = "/CategoriesBackup";


                        backupRestoreSD = new BackupRestoreSD(CategoriesDBpath, CategoriesOutputName, getActivity());
                        boolean CategorySuccess = backupRestoreSD.backup();


                        if (MoneySuccess && CategorySuccess) {
                            Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.sd_backup), Toast.LENGTH_LONG)
                                    .show();
                        }
                        } else {
                            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                        }
                    } else {

                        if (result == PackageManager.PERMISSION_GRANTED) {
                            String MoneyDBpath = "/data/" + getActivity().getPackageName() + "/databases/MoneyDatabase";
                            String MoneyOutputName = "/TransactionsBackup";
                            BackupRestoreSD backupRestoreSD = new BackupRestoreSD(MoneyDBpath, MoneyOutputName, getActivity());
                            boolean MoneySuccess = backupRestoreSD.restore();

                            String CategoriesDBpath = "/data/" + getActivity().getPackageName() + "/databases/categories";
                            String CategoriesOutputName = "/CategoriesBackup";
                            backupRestoreSD = new BackupRestoreSD(CategoriesDBpath, CategoriesOutputName, getActivity());
                            boolean CategorySuccess = backupRestoreSD.restore();

                            if (MoneySuccess && CategorySuccess) {
                                Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.sd_restore), Toast.LENGTH_LONG)
                                        .show();
                            }
                        } else {
                            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                        }
                        }
                    dialog.dismiss();
                }
            });
        }

    }
    //check permission, ask for it if not granted and go to settings for granting it if deny
          @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            if (requestCode == 1) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission granted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission is denied!", Toast.LENGTH_SHORT).show();
                    boolean showRationale = false;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        showRationale = shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE );
                    }
                    if (!showRationale) {
                        openSettingsDialog();
                    }
                }
            }
            super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        }
        //function to open app settings for permission after pressing deny in permission dialog
   private void openSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this,R.style.MyDialogThemeLight);
        builder.setTitle("Required Permission");
        builder.setMessage("This app require permission to backup/restore data. Grant it in app settings.");
        builder.setPositiveButton("Take Me To SETTINGS", (dialog, which) -> {
            dialog.cancel();
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, 101);
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}