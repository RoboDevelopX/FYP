package com.shehryarkamran.pbms.Adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.shehryarkamran.pbms.Extra.LetterImageView;
import com.shehryarkamran.pbms.Model.SpinnerItem;
import com.shehryarkamran.pbms.R;

import java.util.ArrayList;

/**
 * Making calls to findViewById() is really slow in practice, and if your adapter has to call it for each View in
 * your row for every single row then you will quickly run into performance issues.What the ViewHolder class does is
 * cache the call to findViewById(). Once your ListView has reached the max amount of rows it can display on a screen,
 * Android is smart enough to begin recycling those row Views. We check if a View is recycled with if (convertView == null).
 * f it is not null then we have a recycled View and can just change its values, otherwise we need to create a new row View.
 * The magic behind this is the setTag() method which lets us attach an arbitrary object onto a View object, which is how we save
 * the already inflated View for future reuse.
 */
public class CategorySpinnerAdapter extends ArrayAdapter<SpinnerItem> {


    @SuppressLint("ResourceType")
    public CategorySpinnerAdapter(Context context, int resourseID, ArrayList<SpinnerItem> spinnerItems) {

        super(context, resourseID, R.layout.spinner_item_categories, spinnerItems);
    }

    private class ViewHolder {
        TextView tvName;
        LetterImageView liv;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        SpinnerItem item = getItem(position);

        LayoutInflater mInflater = (LayoutInflater) getContext()
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            assert mInflater != null;
            convertView = mInflater.inflate(R.layout.spinner_item_categories, null);
            holder = new ViewHolder();
            holder.tvName = convertView.findViewById(R.id.tvSpinnerCategories);
            holder.liv = convertView.findViewById(R.id.livSpinner);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();

        assert item != null;
        int color = item.getColor();
        char letter = item.getLetter();

        holder.tvName.setText(item.getName());
        holder.tvName.setTextColor(color);
        holder.liv.setLetter(letter);
        holder.liv.setmBackgroundPaint(color);

        return convertView;
    }


    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        SpinnerItem item = getItem(position);

        LayoutInflater mInflater = (LayoutInflater) getContext()
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            assert mInflater != null;
            convertView = mInflater.inflate(R.layout.spinner_item_categories, null);
            holder = new ViewHolder();
            holder.tvName = convertView.findViewById(R.id.tvSpinnerCategories);
            holder.liv = convertView.findViewById(R.id.livSpinner);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();

        assert item != null;
        int color = item.getColor();
        char letter = item.getLetter();

        holder.tvName.setText(item.getName());
        holder.tvName.setTextColor(color);
        holder.liv.setLetter(letter);
        holder.liv.setmBackgroundPaint(color);

        return convertView;
    }
}