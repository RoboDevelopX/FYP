package com.shehryarkamran.pbms.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.shehryarkamran.pbms.Model.GridItem;
import com.shehryarkamran.pbms.R;

import java.util.ArrayList;

/**
 * Making calls to findViewById() is really slow in practice, and if your adapter has to call it for each View in
 * your row for every single row then you will quickly run into performance issues.What the ViewHolder class does is
 * cache the call to findViewById(). Once your ListView has reached the max amount of rows it can display on a screen,
 * Android is smart enough to begin recycling those row Views. We check if a View is recycled with if (convertView == null).
 * f it is not null then we have a recycled View and can just change its values, otherwise we need to create a new row View.
 * The magic behind this is the setTag() method which lets us attach an arbitrary object onto a View object, which is how we save
 * the already inflated View for future reuse.
 */

public class GridAdapter extends ArrayAdapter<GridItem> {

    private final int layoutResourceId;
    private final Context context;
    private final ArrayList<GridItem> data;



    public GridAdapter(Context context, int layoutResourceId, ArrayList<GridItem> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
    }


    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View row = convertView;
        Holder holder;

        if (row == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);

            holder = new Holder();
            holder.txtTitle = row.findViewById(R.id.tvGridItem);
            holder.imageItem = row.findViewById(R.id.ivGridItem);
            row.setTag(holder);
        } else {
            holder = (Holder) row.getTag();
        }

        GridItem item = data.get(position);
        holder.txtTitle.setText(item.getTitle());
        holder.imageItem.setImageBitmap(item.getImage());

        return row;

    }

    class Holder {
        TextView txtTitle;
        ImageView imageItem;

    }
}