package com.shehryarkamran.pbms.Model;

import java.util.ArrayList;

public class ParentItem {

    private final String month;
    private final int year;
    private final ArrayList<ChildItem> childItems;

    //constructor
    public ParentItem(String month,int year){
        this.month=month;
        this.year=year;
        childItems=new ArrayList<>();
    }

    public void addChild(ChildItem childItem){
        childItems.add(childItem);
    }

    public String getMonth(){
        return month;
    }

    public ArrayList<ChildItem> getChildItems(){
        return childItems;
    }

    public double getTotalAmount(){
        double total=0;
        for (int i=0; i<childItems.size(); i++){
            total+=childItems.get(i).getPrice();
        }

        return total;
    }

    public int getYear(){
        return year;
    }
}