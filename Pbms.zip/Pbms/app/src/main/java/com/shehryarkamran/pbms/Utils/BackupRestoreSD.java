package com.shehryarkamran.pbms.Utils;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * class : represents a read/write operation on external storage(disk)
 */
public class BackupRestoreSD {

    private InputStream input;
    private OutputStream output;
    private final String DBPath;
    private final String SDPath;
    private final String outputName;
    private final Context context;

    //constructor
    public BackupRestoreSD(String DBPath, String outputName, Context context) {
        this.DBPath = DBPath;
        this.outputName = outputName;
        this.context = context;

        SDPath = Environment.getExternalStorageDirectory().getPath();

    }

    //method to take backup(write) on disk storage
    public boolean backup() {

        boolean success = false;

        try {

            input = new FileInputStream(Environment.getDataDirectory() + DBPath);
            //Set the output folder on the SD card

            File directory = new File(SDPath + "/Pbms");
            //If this directory doesn't exist create it
            if (!directory.exists()) {
                directory.mkdir();
            }

            output = new FileOutputStream(directory.getPath() + outputName);


            byte[] buffer = new byte[1024];
            int size;
            while ((size = input.read(buffer)) > 0) {
                output.write(buffer, 0, size);
            }

            output.flush();
            output.close();
            input.close();

            success = true;


        } catch (FileNotFoundException e) {
            Toast.makeText(context, "FILE ERROR " + e, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } catch (IOException e) {
            Toast.makeText(context, "IO ERROR " + e, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        return success;
    }

    //method to take restore(read) on disk storage
    public boolean restore() {
        boolean success = false;
        try {

            output = new FileOutputStream(Environment.getDataDirectory() + DBPath);


            File directory = new File(SDPath + "/Pbms");


            input = new FileInputStream(directory.getPath() + outputName);


            byte[] buffer = new byte[1024];
            int size;
            while ((size = input.read(buffer)) > 0) {
                output.write(buffer, 0, size);
            }

            output.flush();
            output.close();
            input.close();

            success = true;


        } catch (FileNotFoundException e) {
            Toast.makeText(context, "FILE ERROR " + e, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } catch (IOException e) {
            Toast.makeText(context, "IO ERROR " + e, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        return success;

    }
}