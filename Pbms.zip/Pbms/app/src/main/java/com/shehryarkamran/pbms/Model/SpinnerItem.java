package com.shehryarkamran.pbms.Model;

/**
 * class : represents spinnerItems
 */

public class SpinnerItem {

    //name of spinnerItems
    private final String name;

    //color of spinnerItem representation
    private final int color;

    //letter to represent spinnerItem
    private final char letter;

    //constructor
    public SpinnerItem(String name,int color,char letter){
        this.name=name;
        this.color=color;
        this.letter=letter;
    }

    /**
     * below are the getters for each attributes
     */

    public String getName(){
        return name;
    }

    public int getColor(){
        return color;
    }

    public char getLetter(){
        return letter;
    }

}