package com.shehryarkamran.pbms.Model;

import java.io.Serializable;

/**
 * class : represents incomeItem
 */
public class IncomeItem implements Serializable {

    //income amount
    private final double amount;

    //income id
    private int id;

    //income date
    private String date;

    //income source
    private String source;

    //income notes
    private final String notes;

    //constructor
    public IncomeItem(double amount, String date, String source,String notes) {
        this.amount = amount;
        this.date = date;
        this.source = source;
        this.notes=notes;
    }

    /**
     * below are the setters and getters for each attributes
     */
    public void setId(int id) {
        this.id = id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getSource() {
        return source;
    }

    public int getId() {
        return id;
    }

    public String getNotes() {
        return notes;
    }
}