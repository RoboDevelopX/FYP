package com.shehryarkamran.pbms.Model;

import android.graphics.Bitmap;

/**
 * class : represents gridItems
 */
public class GridItem {

    private final Bitmap image;
    private String title;

    //constructor
    public GridItem(Bitmap image, String title) {
        super();
        this.image = image;
        this.title = title;
    }

    /**
     * below are the setters and getters for each attributes
     */
    public Bitmap getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}