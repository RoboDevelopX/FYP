package com.shehryarkamran.pbms.Activities;

import android.app.AlertDialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SpinnerAdapter;
import android.widget.Switch;

import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.shehryarkamran.pbms.Data.CategoryDatabase;
import com.shehryarkamran.pbms.Data.MoneyDatabase;
import com.shehryarkamran.pbms.R;
import com.shehryarkamran.pbms.Utils.SharedPrefsManager;
import com.shehryarkamran.pbms.Utils.Themer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//display of income or expense data in pie format
public class PieDistributionActivity extends AppCompatActivity implements ActionBar.OnNavigationListener {

    //database
    private MoneyDatabase moneyDatabase;
    private CategoryDatabase categoryDatabase;

    //View objects for the XML management
    private ArrayList<String> allCategories;
    private ArrayList<String> finalCategories;
    private ArrayList<Entry> values;
    private ArrayList<Integer> colors;
    private double totalAmount;
    private String centerText;

    private ArrayList<String> selectedCategories;
    private ArrayList<String> backup;

    private PieChart pieChart;
    private Switch switchIsExpense;
    private EditText etStart;
    private EditText etEnd;
    private CardView cardCustomDate;

    private boolean isExpense;

    private String startDate, endDate;

    private int primaryTextColor;
    private int selectedDropDownPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //setting theme
        Themer.setThemeToActivity(this);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_pie_distribution);

        //init variables
        init();

        //init UI elements
        initUI();

        //set up UI elements
        setUpUI();

        SpinnerAdapter adapter = ArrayAdapter.createFromResource(this,
                R.array.pie_period_values, R.layout.action_dropdown_spinner_item);

        getSupportActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
        getSupportActionBar().setTitle("");

        getSupportActionBar().setListNavigationCallbacks(adapter, this);


    }

    private void init() {

        moneyDatabase = new MoneyDatabase(this);
        categoryDatabase = new CategoryDatabase(this);

        //get attribute "textCustomColor" value
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = this.getTheme();
        theme.resolveAttribute(R.attr.textCustomColor, typedValue, true);
        primaryTextColor = typedValue.data;

        isExpense = true;

        allCategories = categoryDatabase.getCategories(isExpense);
        selectedCategories = allCategories;

        endDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date(Calendar.getInstance().getTimeInMillis()));
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -10);
        startDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date(c.getTimeInMillis()));


    }

    private void initUI() {
        pieChart = findViewById(R.id.pieDistChart);

        switchIsExpense = findViewById(R.id.switchIsExpense);

        cardCustomDate = findViewById(R.id.cardview_pie_custom_date);
        etStart = findViewById(R.id.etDateFrom);
        etEnd = findViewById(R.id.etDateTo);

    }

    private void setUpUI() {

        customizePieChart();

        switchIsExpense.setOnCheckedChangeListener(switchListener);

        etStart.setText(startDate);
        etEnd.setText(endDate);

        etStart.setOnClickListener(etDatesListener);
        etEnd.setOnClickListener(etDatesListener);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.pie_distribution, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_filters_pie) {
            allCategories = categoryDatabase.getCategories(isExpense);
            boolean[] checked = new boolean[allCategories.size()];
            //check the items that are previously checked
            for (int i = 0; i < checked.length; i++) {
                if (selectedCategories.contains(allCategories.get(i))) {
                    checked[i] = true;
                }
            }
            backup = new ArrayList<>(selectedCategories);
            CharSequence[] cs = allCategories.toArray(new CharSequence[allCategories.size()]);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            // Set the dialog title
            builder.setTitle("Choose categories")
                    // Specify the list array, the items to be selected by default (null for none),
                    // and the listener through which to receive callbacks when items are selected
                    .setMultiChoiceItems(cs, checked,
                            (dialog, which, isChecked) -> {
                                // Else, if the item is already in the array, remove it
                                if (isChecked) {
                                    // If the user checked the item, add it to the selected items
                                    selectedCategories.add(allCategories.get(which));
                                } else selectedCategories.remove(allCategories.get(which));
                            })
                            // Set the action buttons
                    .setPositiveButton(R.string.button_ok, (dialog, id1) -> {
                        // User clicked OK, so save the mSelectedItems results somewhere
                        // or return them to the component that opened the dialog
                        onNavigationItemSelected(selectedDropDownPos, 0);
                    })
                    .setNegativeButton(R.string.button_cancel, (dialog, which) -> selectedCategories = backup);

            builder.create().show();

        }
        return super.onOptionsItemSelected(item);
    }

    private void customizePieChart() {
        pieChart.setHoleColorTransparent(true);

        //activate hole and define the size
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleRadius(50f);

        //draw text in the center
        pieChart.setDrawCenterText(true);
        //define the size of the text in the center of the pie

        //center text color set to primary
        pieChart.setCenterTextColor(primaryTextColor);

        pieChart.setDescription("");

        pieChart.getLegend().setEnabled(false);

        pieChart.setNoDataText(getString(R.string.no_data_text));
    }

    private void initPieCurrentMonth() {
        totalAmount = 0;

        int[] days = {1, 5, 10, 15, 20, 25};
        int firstDay = days[new SharedPrefsManager(this).getPrefsDayStart()];

        values = new ArrayList<>();
        finalCategories = new ArrayList<>();
        colors = new ArrayList<>();

        for (int i = 0; i < allCategories.size(); i++) {
            double amount = moneyDatabase.getMonthTotalForCategory(allCategories.get(i), isExpense);
            //if this category has positive amount
            if (amount > 0 && selectedCategories.contains(allCategories.get(i))) {
                totalAmount += amount;
                //add it in the pie
                Entry e = new Entry(
                        (float) amount, i);
                values.add(e);
                finalCategories.add(allCategories.get(i));
                colors.add(categoryDatabase.getColorFromCategory(allCategories.get(i), isExpense));
            }
        }
        totalAmount = Math.round(totalAmount * 100) / 100.0;

        //get the current month's name
        Calendar c = Calendar.getInstance();
        int month = c.get(Calendar.MONTH);

        //if first day of Month is 1 , then show month name
        if (firstDay == 1) {

            //get month name

            centerText = OverviewActivity.getMonthForInt(month);
            //else show the period
        } else {


            Date startDate, endDate;

            c.set(Calendar.DAY_OF_MONTH, firstDay);
            startDate = c.getTime();

            c.add(Calendar.MONTH, 1);
            c.add(Calendar.DAY_OF_MONTH, -1);
            endDate = c.getTime();

            centerText = getString(R.string.text_period) + "\n("
                    + new SimpleDateFormat("dd MMM").format(startDate) + "-" +
                    new SimpleDateFormat("dd MMM").format(endDate) + ")";

        }

        //and set it to the center text
        pieChart.setCenterTextSize(20f);

        String mode = isExpense ? "Expense" : "Income";

        setDataToPie(values, finalCategories, colors, mode);
    }

    private void initPieCurrentWeek() {
        totalAmount = 0;

        int[] days = {Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
                Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY};
        int firstDay = days[new SharedPrefsManager(this).getPrefsDayStart()];

        values = new ArrayList<>();
        finalCategories = new ArrayList<>();
        colors = new ArrayList<>();

        for (int i = 0; i < allCategories.size(); i++) {
            double amount = moneyDatabase.getWeekTotalForCategory(firstDay, allCategories.get(i), isExpense);
            //if this category has positive amount
            if (amount > 0 && selectedCategories.contains(allCategories.get(i))) {
                totalAmount += amount;
                //add it in the pie
                Entry e = new Entry(
                        (float) amount, i);
                values.add(e);
                finalCategories.add(allCategories.get(i));
                colors.add(categoryDatabase.getColorFromCategory(allCategories.get(i), isExpense));
            }
        }
        totalAmount = Math.round(totalAmount * 100) / 100.0;

        Calendar c = Calendar.getInstance();

        int currentDay = c.get(Calendar.DAY_OF_WEEK);

        Date startDate, endDate;

        if (firstDay == currentDay) {
            startDate = c.getTime();
            c.add(Calendar.DAY_OF_YEAR, 6);
            endDate = c.getTime();
        } else {
            while (currentDay != firstDay) {
                c.add(Calendar.DATE, 1);
                currentDay = c.get(Calendar.DAY_OF_WEEK);
            }
            c.add(Calendar.DAY_OF_YEAR, -1);
            endDate = c.getTime();
            c.add(Calendar.DAY_OF_YEAR, -6);
            startDate = c.getTime();
        }
        if (startDate.getMonth() == endDate.getMonth()) {
            centerText = new SimpleDateFormat("dd").format(startDate)
                    + "-" + new SimpleDateFormat("dd MMM").format(endDate);
        } else {
            centerText = new SimpleDateFormat("dd MMM").format(startDate)
                    + "-" + new SimpleDateFormat("dd MMM").format(endDate);
        }

        pieChart.setCenterTextSize(25f);
        pieChart.setCenterText(centerText);
        String mode = isExpense ? "Expense" : "Income";

        setDataToPie(values, finalCategories, colors, mode);
    }

    private void initPieCustomPeriod() {
        totalAmount = 0;

        int count = allCategories.size();

        values = new ArrayList<>();
        finalCategories = new ArrayList<>();
        colors = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            double amount = moneyDatabase.getTotalForCategoryCustomDate(startDate, endDate, allCategories.get(i), isExpense);
            //if this category has positive amount
            if (amount > 0 && selectedCategories.contains(allCategories.get(i))) {
                totalAmount += amount;
                //add it in the pie
                Entry e = new Entry(
                        (float) amount, i);
                values.add(e);
                finalCategories.add(allCategories.get(i));
                colors.add(categoryDatabase.getColorFromCategory(allCategories.get(i), isExpense));
            }
        }
        totalAmount = Math.round(totalAmount * 100) / 100.0;

        String mode = isExpense ? "Expense" : "Income";

        try {
            Date sDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDate);
            Date eDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDate);
            if (sDate.getMonth() == eDate.getMonth()) {
                centerText = new SimpleDateFormat("dd").format(sDate) +
                        "-" + new SimpleDateFormat("dd MMM").format(eDate);
            } else {
                centerText = new SimpleDateFormat("dd MMM").format(sDate) +
                        "-" + new SimpleDateFormat("dd MMM").format(eDate);
            }

            pieChart.setCenterTextSize(20f);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        setDataToPie(values, finalCategories, colors, mode);
    }

    private void initPieDay() {
        totalAmount = 0;

        values = new ArrayList<>();
        finalCategories = new ArrayList<>();
        colors = new ArrayList<>();

        for (int i = 0; i < allCategories.size(); i++) {
            double amount = moneyDatabase.getDailyTotalForCategory(allCategories.get(i), isExpense);
            //if this category has positive amount
            if (amount > 0 && selectedCategories.contains(allCategories.get(i))) {
                totalAmount += amount;
                //add it in the pie
                Entry e = new Entry(
                        (float) amount, i);
                values.add(e);
                finalCategories.add(allCategories.get(i));
                colors.add(categoryDatabase.getColorFromCategory(allCategories.get(i), isExpense));
            }
        }
        totalAmount = Math.round(totalAmount * 100) / 100.0;

        centerText = "Today";

        pieChart.setCenterTextSize(20f);

        String mode = isExpense ? "Expense" : "Income";

        setDataToPie(values, finalCategories, colors, mode);
    }

    private void initPieTotal() {
        totalAmount = 0;

        values = new ArrayList<>();
        finalCategories = new ArrayList<>();
        colors = new ArrayList<>();

        for (int i = 0; i < allCategories.size(); i++) {
            double amount = moneyDatabase.getTotalForCategory(allCategories.get(i), isExpense);
            //if this category has positive amount
            if (amount > 0 && selectedCategories.contains(allCategories.get(i))) {
                totalAmount += amount;
                //add it in the pie
                Entry e = new Entry(
                        (float) amount, i);
                values.add(e);
                finalCategories.add(allCategories.get(i));
                colors.add(categoryDatabase.getColorFromCategory(allCategories.get(i), isExpense));
            }
        }
        totalAmount = Math.round(totalAmount * 100) / 100.0;
        centerText = "Total";

        //and set it to the center text
        pieChart.setCenterTextSize(20f);

        String mode = isExpense ? "Expense" : "Income";

        setDataToPie(values, finalCategories, colors, mode);
    }

    private void setDataToPie(ArrayList values, ArrayList finalCategories, ArrayList colors, String mode) {
        PieDataSet dataSet = new PieDataSet(values, mode + " Distribution");

        //set slice width
        dataSet.setSliceSpace(2f);
        //set the colors in the pie
        dataSet.setColors(colors);

        //set the categories
        PieData data = new PieData(finalCategories, dataSet);
        //set the formatter a currency
        data.setValueFormatter(value -> PreferenceManager.getDefaultSharedPreferences(PieDistributionActivity.this)
                .getString(getString(R.string.pref_key_currency), "€") + " " + value);

        //set the color of the values
        data.setValueTextColor(primaryTextColor);
        //set text size of values
        data.setValueTextSize(15f);
        //set data to the pie
        pieChart.setData(data);

        if (finalCategories.size() == 0) {
            pieChart.setDrawCenterText(false);
        } else {
            pieChart.setDrawCenterText(true);
            if (totalAmount == (int) totalAmount) {
                pieChart.setCenterText(centerText + "\n" + PreferenceManager.getDefaultSharedPreferences(PieDistributionActivity.this)
                                .getString(getString(R.string.pref_key_currency), "€") + (int) totalAmount );
            } else {
                pieChart.setCenterText(centerText + "\n" + PreferenceManager.getDefaultSharedPreferences(PieDistributionActivity.this)
                                .getString(getString(R.string.pref_key_currency), "€") + totalAmount );
            }
        }

        // undo all highlights
        pieChart.highlightValues(null);

        //animate pie createion
        pieChart.animateXY(1000, 1000);
        //invalidate

        pieChart.invalidate();
    }

    private final CompoundButton.OnCheckedChangeListener switchListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            isExpense = !isChecked;
            allCategories = categoryDatabase.getCategories(isExpense);
            selectedCategories = allCategories;
            onNavigationItemSelected(selectedDropDownPos, 0);
        }
    };

    private final View.OnClickListener etDatesListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Bundle bundle = new Bundle();
            if (v.getId() == R.id.etDateFrom) {
                bundle.putBoolean("isStartDate", true);
            } else {
                bundle.putBoolean("isStartDate", false);
            }
            CalendarDatePickerDialog dialog = new CalendarDatePickerDialog();
            dialog.setOnDateSetListener(dateSetListener);
            dialog.setArguments(bundle);
            dialog.show(getSupportFragmentManager(), "Date");
        }
    };

    private final CalendarDatePickerDialog.OnDateSetListener dateSetListener = new CalendarDatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(CalendarDatePickerDialog calendarDatePickerDialog, int year, int month, int day) {
            Calendar c = Calendar.getInstance();
            c.set(year, month, day);
            Date d = new Date(c.getTimeInMillis());
            String date = new SimpleDateFormat("dd-MM-yyyy").format(d);
            if (calendarDatePickerDialog.getArguments().getBoolean("isStartDate")) {
                startDate = date;
                etStart.setText(startDate);
            } else {
                endDate = date;
                etEnd.setText(endDate);
            }
            initPieCustomPeriod();
        }
    };

    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId) {
        selectedDropDownPos = itemPosition;
        if (itemPosition == 4) {
            cardCustomDate.setVisibility(View.VISIBLE);
            initPieCustomPeriod();
        } else {
            cardCustomDate.setVisibility(View.INVISIBLE);

            switch (itemPosition) {
                case 0:
                    initPieCurrentMonth();
                    break;
                case 1:
                    initPieCurrentWeek();
                    break;
                case 2:
                    initPieDay();
                    break;
                case 3:
                    initPieTotal();
            }
            if (itemPosition == 0) {
                initPieCurrentMonth();

            } else if (itemPosition == 1) {

                initPieCurrentWeek();

            }
        }
        return true;
    }
}