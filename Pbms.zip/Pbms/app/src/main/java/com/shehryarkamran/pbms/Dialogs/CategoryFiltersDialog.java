package com.shehryarkamran.pbms.Dialogs;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.shehryarkamran.pbms.Data.CategoryDatabase;
import com.shehryarkamran.pbms.R;

import java.util.ArrayList;

//all categories retrieve from database and will be shown in a dialog for filtration by giving it a view

public class CategoryFiltersDialog extends DialogFragment {

    //database
    private CategoryDatabase categoryDatabase;

    //listView
    private ListView listView;

    //adapter
    private CustomAdapter adapter;

    private Dialog dialog;

    //ArrayList
    private ArrayList<String> checkedCategories;


    //constructor
    public CategoryFiltersDialog() { }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        dialog = new Dialog(getActivity());
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_categories_filters);

        checkedCategories = (ArrayList) getArguments().getSerializable("arg");

        //init variables
        init();

        //init UI elements
        initUI();

        //set up UI elements
        setUpUI();

        return dialog;
    }


    private void initUI() {
        //init lv
        listView = dialog.findViewById(R.id.listCategories);
    }

    private void init() {
        categoryDatabase = new CategoryDatabase(getActivity());

        //init adapter
        adapter = new CustomAdapter(getActivity(), checkedCategories);

    }

    private void setUpUI() {

        //set the adapter to the listview
        listView.setAdapter(adapter);
    }

    private class CustomAdapter extends ArrayAdapter<String> {

        private final ArrayList<String> allCategories;
        private final int resource;

        CustomAdapter(Context context, ArrayList<String> checkedCategories) {
            super(context, R.layout.list_item_category_filter, checkedCategories);
            allCategories = categoryDatabase.getCategories(true);
            this.resource = R.layout.list_item_category_filter;
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = getActivity().getLayoutInflater().inflate(resource, parent, false);
            }

            CheckBox checkBox = convertView.findViewById(R.id.chbCategory);
            checkBox.setChecked(true);
            checkBox.setText(allCategories.get(position) );
            return convertView;
        }
    }
}