package com.shehryarkamran.pbms.Adapters;

import android.content.Context;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.shehryarkamran.pbms.Data.CategoryDatabase;
import com.shehryarkamran.pbms.Extra.LetterImageView;
import com.shehryarkamran.pbms.Model.ChildItem;
import com.shehryarkamran.pbms.Model.ParentItem;
import com.shehryarkamran.pbms.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import me.grantland.widget.AutofitTextView;

/**
 * Making calls to findViewById() is really slow in practice, and if your adapter has to call it for each View in
 * your row for every single row then you will quickly run into performance issues.What the ViewHolder class does is
 * cache the call to findViewById(). Once your ListView has reached the max amount of rows it can display on a screen,
 * Android is smart enough to begin recycling those row Views. We check if a View is recycled with if (convertView == null).
 * f it is not null then we have a recycled View and can just change its values, otherwise we need to create a new row View.
 * The magic behind this is the setTag() method which lets us attach an arbitrary object onto a View object, which is how we save
 * the already inflated View for future reuse.
 */

public class HistoryAdapter extends BaseExpandableListAdapter {

    private final Context context;
    private ArrayList<ParentItem> groupItems;
    private LayoutInflater inflater;
    private final String currency;
    private final CategoryDatabase cdb;
    private final boolean expense;

    public HistoryAdapter(Context context, ArrayList<ParentItem> groupItems, boolean expense) {
        this.context = context;
        currency = PreferenceManager.getDefaultSharedPreferences(context).getString(context.getResources().getString(R.string.pref_key_currency), context.getResources().getString(R.string.pref_currency_default_value));
        this.groupItems = groupItems;
        cdb = new CategoryDatabase(this.context);
        this.expense = expense;
    }

    @Override
    public int getGroupCount() {
        return groupItems.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return groupItems.get(groupPosition).getChildItems().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groupItems.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return groupItems.get(groupPosition).getChildItems().get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isLastChild, View view, ViewGroup viewGroup) {

        ParentItem parent = (ParentItem) getGroup(groupPosition);
        if (view == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            view = inflater.inflate(R.layout.group_item, viewGroup, false);

        }

        AutofitTextView tvGroupName = view.findViewById(R.id.tvGroupName);
        AutofitTextView tvGroupAmount = view.findViewById(R.id.tvGroupAmount);

        tvGroupName.setText(parent.getMonth() + " " + parent.getYear());
        double total = Math.round(parent.getTotalAmount() * 100) / 100.0;
        tvGroupAmount.setText(currency + " " + total);

        if (expense) {
            tvGroupAmount.setTextColor(context.getResources().getColor(R.color.red));
        } else {
            tvGroupAmount.setTextColor(context.getResources().getColor(R.color.green));
        }


        return view;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View view, ViewGroup viewGroup) {
        ChildItem childItem = (ChildItem) getChild(groupPosition, childPosition);
        if (view == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            view = inflater.inflate(R.layout.list_history_item, viewGroup, false);
        }
        TextView tvPrice = view.findViewById(R.id.tvPrice);
        TextView tvDate = view.findViewById(R.id.tvDate);
        AutofitTextView tvCategory = view.findViewById(R.id.tvCategory);
        TextView tvNotes = view.findViewById(R.id.tvNotes);
        LetterImageView liv = view.findViewById(R.id.livhistory);

        tvPrice.setText(currency +  " " + childItem.getPrice());
        tvPrice.setTextColor(context.getResources().getColor(R.color.red));

        //We take the date from the cursor we reformed it and we add it to TextView tvDate. We do that cause the format of
        //date in MoneyDatabase is YYYY-MM-DD and we want the user to see it like DD-MM-YYYY
        String date = childItem.getDate();

        try {
            Calendar today = Calendar.getInstance();
            Calendar yesterday = Calendar.getInstance();
            yesterday.add(Calendar.DAY_OF_YEAR, -1);
            Calendar item_date = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            item_date.setTime(format.parse(date));

            boolean isToday = today.get(Calendar.YEAR) == item_date.get(Calendar.YEAR) &&
                    today.get(Calendar.DAY_OF_YEAR) == item_date.get(Calendar.DAY_OF_YEAR);
            boolean isYesterday = yesterday.get(Calendar.YEAR) == item_date.get(Calendar.YEAR) &&
                    yesterday.get(Calendar.DAY_OF_YEAR) == item_date.get(Calendar.DAY_OF_YEAR);
            if (isToday) {
                tvDate.setText(context.getString(R.string.text_today));
            } else if (isYesterday) {
                tvDate.setText(context.getString(R.string.text_yesterday));
            } else {
                String[] dateTokens = date.split("-");
                String reformedDate = dateTokens[2] + "-" + dateTokens[1] + "-" + dateTokens[0];

                SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");

                Date d = fmt.parse(reformedDate);
                SimpleDateFormat fmtOut = new SimpleDateFormat("EEE d MMMM");
                assert d != null;
                tvDate.setText(fmtOut.format(d));
            }


        } catch (ParseException e) {
            e.printStackTrace();
        }


        tvCategory.setText(childItem.getCategory());

        int color = cdb.getColorFromCategory(childItem.getCategory(), expense);
        char letter = cdb.getLetterFromCategory(childItem.getCategory(), expense);

        tvCategory.setTextColor(color);

        liv.setLetter(letter);
        liv.setmBackgroundPaint(color);


        tvNotes.setText(childItem.getNotes());

        if (expense) tvPrice.setTextColor(context.getResources().getColor(R.color.red));
        else tvPrice.setTextColor(context.getResources().getColor(R.color.green));


        return view;
    }

    public void closeCDB() {
        cdb.close();
    }


    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    public void setUpdateGroupItems(ArrayList<ParentItem> newGroups) {
        this.groupItems = newGroups;
    }
}